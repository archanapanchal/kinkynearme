<?php $__env->startSection('page-title', __tr('Subscription plans')); ?>
<?php $__env->startSection('head-title', __tr('Subscription plans')); ?>
<?php $__env->startSection('keywordName', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('keyword', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('description', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('keywordDescription', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('page-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('twitter-card-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('page-url', url()->current()); ?>

<!-- include header -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /include header -->

<section class="plan-for-you subscription-plan-v1 subscription-plan">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="heading-title"><?= __tr('SUBSCRIPTION PLAN') ?></h2>
                <p class="title-para"><?= __tr('Monthly Plan you have selected') ?></p>
            </div>
        </div>
        <div id="content" class="tab-content" role="tablist">
            <div id="pane-A" class="card tab-pane fade show active" role="tabpanel" aria-labelledby="tab-A">
                <!-- Note: New place of `data-parent` -->
                <div id="collapse-A" class="collapse show" data-parent="#content" role="tabpanel" aria-labelledby="heading-A">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-5 col-md-6 subscription-border">
                                <div class="subscription-plan-desc">
                                    <div class="d-flex">
                                        <span class="back-button"><a href="<?= route('user.subscription.plans') ?>">back</a></span>
                                        <h2 class="heading-title"><?= strtoupper($planData['title']) ?></h2>
                                    </div>
                                    <?= $planData['description'] ?>
                                    <a href="<?= route('user.subscription.plan.process', ['planId' => $planData['_id']]) ?>" class="btn btn-primary"><?= __tr('PROCEED') ?></a>
                                    <a href="<?= route('user.subscription.plans') ?>" class="change-plan-button"><?= __tr('Change Plan') ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php $__env->startPush('appScripts'); ?>
    <script>
    
</script>
<?php $__env->stopPush(); ?>


<!-- include footer -->
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /include footer --><?php /**PATH /var/www/html/knm/resources/views/user/subscription/plan.blade.php ENDPATH**/ ?>