<?php $__env->startSection('page-title', __tr('Forgot Your Password?')); ?>
<?php $__env->startSection('head-title', __tr('Forgot Your Password?')); ?>
<?php $__env->startSection('keywordName', strip_tags(__tr('Forgot Your Password?'))); ?>
<?php $__env->startSection('keyword', strip_tags(__tr('Forgot Your Password?'))); ?>
<?php $__env->startSection('description', strip_tags(__tr('Forgot Your Password?'))); ?>
<?php $__env->startSection('keywordDescription', strip_tags(__tr('Forgot Your Password?'))); ?>
<?php $__env->startSection('page-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('twitter-card-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('page-url', url()->current()); ?>

<!-- include header -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /include header -->


<section class="login-section">
    <div class="form-login fadeInDown">
    <div class="form-title text-center">
        <h2 class="heading-title"><?= __tr('Forgot Your Password?')  ?></h2>
        <p class="title-para"><?= __tr("We get it, stuff happens. Just enter your email address below and we'll send you a link to reset your password!")  ?></p>
    </div>
    <div id="formContent">
		<!-- forgot password form form -->
		<form class="form-field-fontent user lw-ajax-form lw-form" method="post" action="<?= route('user.forgot_password.process') ?>">
			<!-- email input field -->
			<div class="form-group">
				<label for="inputAddress"><?= __tr('Email address')  ?></label>
				<input type="email" class="form-control form-control-user" name="email" aria-describedby="emailHelp" placeholder="<?= __tr('Ex. johnsmith@gmail.com') ?>" required>
			</div>
			<!-- / email input field -->

			<!-- Reset Password button -->
			<div class="login-button">
				<button type="submit" class="lw-ajax-form-submit-action btn btn-primary btn-user btn-block">
					<?= __tr('Reset Password')  ?>
				</button>
			</div>
			<!-- Reset Password button -->
		</form>
								
		<div id="formFooter">
            <a class="underlineHover" href="<?= route('user.login') ?>"><?= __tr('Login now')  ?></a>
        </div>
	</div>
</section>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/knm/resources/views/user/forgot-password.blade.php ENDPATH**/ ?>