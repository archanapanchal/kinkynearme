<?php $__env->startSection('page-title', __tr("Generate Fake Users")); ?>
<?php $__env->startSection('head-title', __tr("Generate Fake Users")); ?>
<?php $__env->startSection('keywordName', strip_tags(__tr("Generate Fake Users"))); ?>
<?php $__env->startSection('keyword', strip_tags(__tr("Generate Fake Users"))); ?>
<?php $__env->startSection('description', strip_tags(__tr("Generate Fake Users"))); ?>
<?php $__env->startSection('keywordDescription', strip_tags(__tr("Generate Fake Users"))); ?>
<?php $__env->startSection('page-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('twitter-card-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('page-url', url()->current()); ?>

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
	<h1 class="h3 mb-0 text-gray-200"><?= __tr('Generate Fake Users') ?></h1>
</div>

<!-- Start of Page Wrapper -->
<div class="row">
	<div class="col-xl-12 mb-4">
		<!-- card -->
		<div class="card mb-4">
			<!-- card body -->
			<div class="card-body">
				<!-- User add form -->
				<form class="lw-form" method="post" data-show-processing="true" id="fakeUsersForm" action="<?= route('manage.fake_users.write.create') ?>" data-callback="fakeUsersCallback">
					<div class="form-group row">

						<!-- Number of users -->
						<div class="col-sm-6 mb-3 mb-sm-0">
							<label for="lwNumberOfUser"><?= __tr('Number of users') ?></label>
							<input type="number" name="number_of_users" class="form-control form-control-user" id="lwNumberOfUser" required min="1" max="<?= $recordsLimit ?>" value="1">
						</div>
						<!-- / Number of users -->

						<!-- Country -->
						<div class="col-sm-6 mb-3 mb-sm-0">
							<label for="lwSelectCountry"><?= __tr('Select a Country') ?></label>
							<select id="lwCountrySelect" required class="form-control" id="lwSelectCountry" name="country">
								<?php if(!__isEmpty($countries)): ?>
								<option value="random" ><?= __tr('Random') ?></option>
								<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?= $country['id'] ?>"><?= $country['name'] ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<!-- / Country -->
					</div>

					<div class="form-group row">

						<!-- Gender -->
						<div class="col-sm-6 mb-3 mb-sm-0">
							<label for="lwSelectGender"><?= __tr('Select a Gender') ?></label>
							<select id="lwGenderSelect" required class="form-control" id="lwSelectGender" name="gender">
								<?php if(!__isEmpty($gender)): ?>
								<option value="random" ><?= __tr('Random') ?></option>
								<?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?= $key ?>" required><?= $gen ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<!-- / Gender -->

						<!-- Language -->
						<div class="col-sm-6 mb-3 mb-sm-0">
							<label for="lwSelectLanguage"><?= __tr('Select a Language') ?></label>
							<select id="lwLanguageSelect" required class="form-control" id="lwSelectLanguage" name="language">
								<?php if(!__isEmpty($languages)): ?>
								<option value="random" ><?= __tr('Random') ?></option>
								<?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?= $key ?>" ><?= $language ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</select>
						</div>
						<!-- / Language -->
					</div>

					<div class="form-group row">

						<!-- Default Password -->
						<div class="col-sm-6 mb-3 mb-sm-0">
							<label for="lwDefaultPassword"><?= __tr('Default Password') ?></label>
							<input type="text" class="form-control form-control-user" name="default_password" id="lwDefaultPassword" value="<?= $default_password ?>">
						</div>
						<!-- / Default Password -->

						<!-- Age From -->
						<div class="col-sm-3 mb-3 mb-sm-0">
							<label for="lwAgeFrom"><?= __tr('Age from') ?></label>
							<input type="text" name="age_from" required id="lwAgeFrom" class="form-control form-control-user" aria-label="Age From" value="<?= $ageRestriction['minimum'] ?>">

						</div>
						<!-- / Age From -->
						<!-- Age To -->
						<div class="col-sm-3 mb-3 mb-sm-0">
							<label for="lwAgeTo"><?= __tr('Age to') ?></label>
							<input type="text" name="age_to" required id="lwAgeTo" class="form-control form-control-user" aria-label="Age From" value="<?= $ageRestriction['maximum'] ?>">

						</div>
						<!-- / Age To -->
					</div>

					<!-- / status field -->
					<button type="submit" class="btn btn-primary lw-btn-block-mobile lw-ajax-form-submit-action"><?= __tr('Generate Fake Users') ?></button>
				</form>
				<!-- /User add form -->
			</div>
			<!-- /card body -->
		</div>
		<!-- /card -->
	</div>
</div>
<!-- End of Page Wrapper -->

<?php $__env->startPush('appScripts'); ?>
<script type="text/javascript">
	//initialize selectize element
	$(function() {
		$('#lwCountrySelect').selectize({
			valueField: 'currency_code',
			labelField: 'currency_name',
			searchField: ['currency_code', 'currency_name']
		});
	});

	//initialize selectize element
	$(function() {
		$('#lwGenderSelect').selectize({
			valueField: 'currency_code',
			labelField: 'currency_name',
			searchField: ['currency_code', 'currency_name']
		});
	});

	//initialize selectize element
	$(function() {
		$('#lwLanguageSelect').selectize({
			valueField: 'currency_code',
			labelField: 'currency_name',
			searchField: ['currency_code', 'currency_name']
		});
	});


	//reset form
	function fakeUsersCallback(response) {
		if (response.reaction == 1) {
			$('#fakeUsersForm')[0].reset();
		}
	}
</script>
<?php $__env->stopPush(); ?><?php /**PATH /var/www/html/knm/resources/views/fake-data-generator/fake-users.blade.php ENDPATH**/ ?>