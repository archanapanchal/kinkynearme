<?php $__env->startSection('page-title', __tr('Subscription plans')); ?>
<?php $__env->startSection('head-title', __tr('Subscription plans')); ?>
<?php $__env->startSection('keywordName', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('keyword', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('description', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('keywordDescription', strip_tags(__tr('Subscription plans'))); ?>
<?php $__env->startSection('page-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('twitter-card-image', getStoreSettings('logo_image_url')); ?>
<?php $__env->startSection('page-url', url()->current()); ?>

<!-- include header -->
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /include header -->


<section class="plan-for-you subscription-plan-v1">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <span class="back-button"><a href="<?= route('user.profile.build') ?>"><?= __tr('Back') ?></a></span>
                <h2 class="heading-title"><?= __tr('SUBSCRIPTION PLAN') ?></h2>
                <p class="title-para"><?= __tr('Monthly Plan you have selected') ?></p>
            </div>
        </div>

        <!-- <ul id="tabs" class="nav nav-tabs" role="tablist">
            <?php $planTypes = configItem('plan_settings.type');    ?>

            <?php
            $i = 0
            ?>

            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $planList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a id="tab-<?= $type ?>" href="#pane-<?= $type ?>" class="nav-link <?php if($i == 0): ?> active <?php endif; ?>" data-toggle="tab" role="tab"><?= __tr('Bill') ?> <?= isset($planTypes[$type]) ? $planTypes[$type] : null; ?></a>
            </li>
            <?php
            $i++
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul> -->
        <div id="content" class="tab-content" role="tablist">

            <?php
            $i = 0
            ?>

            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $planList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="pane-<?= $type ?>" class="card tab-pane fade <?php if($i == 0): ?> show active <?php endif; ?>" role="tabpanel" aria-labelledby="tab-<?= $type ?>">
                <!-- Note: New place of `data-parent` -->
                <div id="collapse-<?= $type ?>" class="collapse <?php if($i == 0): ?> show <?php endif; ?>" data-parent="#content" role="tabpanel" aria-labelledby="heading-<?= $type ?>">
                    <div class="card-body">
                        <div class="row mobile-hide">
                            <?php $__currentLoopData = $planList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 subscription-border">
                                <div class="subscription-plan-desc">
                                    <h2 class="heading-title"><?= strtoupper($plan['title']) ?></h2>
                                    <?= $plan['content'] ?>
                                    <a href="<?= route('user.subscription.plan.process', ['planId' => $plan['_id']]) ?>" class="btn btn-primary choose-button"><?= __tr('PROCEED') ?></a>
                                    
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div    class="owl-carousel sld2 logos mobile-show">
                            <?php $__currentLoopData = $planList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 col-sm-12 col-sx-12 subscription-border">
                                <div class="subscription-plan-desc">
                                    <h2 class="heading-title"><?= strtoupper($plan['title']) ?></h2>
                                    <?= $plan['content'] ?>
                                    <a href="<?= route('user.subscription.plan.process', ['planId' => $plan['_id']]) ?>" class="btn btn-primary choose-button"><?= __tr('PROCEED') ?></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- slider-end -->
                    </div>
                </div>
            </div>
            <?php
            $i++
            ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>



<?php $__env->startPush('appScripts'); ?>
    <script>
    
</script>
<?php $__env->stopPush(); ?>


<!-- include footer -->
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /include footer --><?php /**PATH /var/www/html/knm/resources/views/user/subscription/plans.blade.php ENDPATH**/ ?>