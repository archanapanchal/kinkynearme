<section class="about">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="breadcrumbs">
                    <ol>
                        <li class="breadcrumb-item"><a href="<?= route('landing_page') ?>">Home</a></li>
                        <li class="breadcrumb-item active"><span><?= $pageData['title'] ?></span></li>
                    </ol>
                </div>
            </div>
        </div>
      
        <div class="row">
            <div class="col-md-12">
                <h4 class="heading-title-h4"><?= $pageData['title'] ?></h4>
                <?= $pageData['description'] ?>
            </div>
       </div>
    </div>
</section>
