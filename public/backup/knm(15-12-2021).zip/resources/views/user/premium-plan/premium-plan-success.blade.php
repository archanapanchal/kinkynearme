 <!-- Page Heading -->
 <div class="lw-premium-success-msg mt-5">
 	<?= __tr('Congratulations') ?> <i class="fa fa-smile" aria-hidden="true"></i>
 </div>
 <div class="text-center mt-3">
 	<span><?= __tr('You are the Premium User now') ?></span>
 </div>