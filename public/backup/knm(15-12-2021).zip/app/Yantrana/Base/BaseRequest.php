<?php

namespace App\Yantrana\Base;

use App\Yantrana\__Laraware\Core\CoreRequest;

abstract class BaseRequest extends CoreRequest
{
}
