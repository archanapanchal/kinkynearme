<?php

$defaultKinkOptions = [
                    'abrasion' => __tr('Abrasion'),
                    'age-play-not-pedophilia' => __tr('Age Play (not pedophilia)'),
                    'airtight' => __tr('Airtight'),
                    'anal' => __tr('Anal'),
                    'anal-play' => __tr('Anal Play'),
                    'anal-plugs' => __tr('Anal Plugs'),
                    'anal-sex' => __tr('Anal Sex'),
                    'animal-roleplay' => __tr('Animal Roleplay'),
                    'armpits' => __tr('Armpits'),
                    'asphyxiation' => __tr('Asphyxiation'),
                    'auctioned-for-charity' => __tr('Auctioned for Charity'),
                    'bdsm' => __tr('BDSM'),
                    'ball-busting' => __tr('Ball Busting'),
                    'ball-gag' => __tr('Ball Gag'),
                    'ball-stretching' => __tr('Ball Stretching'),
                    'beating' => __tr('Beating'),
                    'bedroom-submissive' => __tr('Bedroom Submissive'),
                    'bit-gag' => __tr('Bit Gag'),
                    'blindfolds' => __tr('Blindfolds'),
                    'blood-play' => __tr('Blood Play'),
                    'blowjobs' => __tr('Blowjobs'),
                    'body-modification' => __tr('Body Modification'),
                    'bondage' => __tr('Bondage'),
                    'boot-worship' => __tr('Boot Worship'),
                    'branding' => __tr('Branding'),
                    'breast-bondage' => __tr('Breast Bondage'),
                    'breast-fucking' => __tr('Breast Fucking'),
                    'breast-whipping' => __tr('Breast Whipping'),
                    'breath-control' => __tr('Breath Control'),
                    'bukkake' => __tr('Bukkake'),
                    'bullwhip' => __tr('Bullwhip'),
                    'butler' => __tr('Butler'),
                    'cbt' => __tr('CBT'),
                    'cfnf' => __tr('CFNF'),
                    'cfnm' => __tr('CFNM'),
                    'cmnf' => __tr('CMNF'),
                    'cmnm' => __tr('CMNM'),
                    'cnc' => __tr('CNC'),
                    'cages' => __tr('Cages'),
                    'caning' => __tr('Caning'),
                    'cat-of-9-tails' => __tr('Cat of 9 Tails'),
                    'cat-o-nine' => __tr('Cat-o-Nine'),
                    'catheters' => __tr('Catheters'),
                    'chains' => __tr('Chains'),
                    'chastity' => __tr('Chastity'),
                    'chastity-devices' => __tr('Chastity Devices'),
                    'chauffeuring' => __tr('Chauffeuring'),
                    'chores' => __tr('Chores'),
                    'clamps' => __tr('Clamps'),
                    'clothespins' => __tr('Clothespins'),
                    'cock-slapping' => __tr('Cock Slapping'),
                    'cock-worship' => __tr('Cock Worship'),
                    'collars' => __tr('Collars'),
                    'commands' => __tr('Commands'),
                    'consensual-non-consent' => __tr('Consensual Non-Consent'),
                    'contracts' => __tr('Contracts'),
                    'corner-time' => __tr('Corner Time'),
                    'corporal-punishment' => __tr('Corporal Punishment'),
                    'corsets' => __tr('Corsets'),
                    'crops' => __tr('Crops'),
                    'crossdressing' => __tr('Crossdressing'),
                    'cuckold' => __tr('Cuckold'),
                    'cuffs' => __tr('Cuffs'),
                    'cunnilingus' => __tr('Cunnilingus'),
                    'cutting' => __tr('Cutting'),
                    'dap' => __tr('DAP'),
                    'dp' => __tr('DP'),
                    'dvp' => __tr('DVP'),
                    'ddlg' => __tr('Ddlg'),
                    'depilation' => __tr('Depilation'),
                    'deprivation' => __tr('Deprivation'),
                    'diapers' => __tr('Diapers'),
                    'dilation' => __tr('Dilation'),
                    'dildos' => __tr('Dildos'),
                    'dom' => __tr('Dom'),
                    'domestic-service' => __tr('Domestic Service'),
                    'dominance' => __tr('Dominance'),
                    'domme' => __tr('Domme'),
                    'double-penetration' => __tr('Double Penetration'),
                    'edge-play' => __tr('Edge Play'),
                    'electrical-play' => __tr('Electrical Play'),
                    'electricity' => __tr('Electricity'),
                    'enemas' => __tr('Enemas'),
                    'erotic-dancing' => __tr('Erotic Dancing'),
                    'examinations' => __tr('Examinations'),
                    'exercise' => __tr('Exercise'),
                    'exhibitionism' => __tr('Exhibitionism'),
                    'eye-contact-restrictions' => __tr('Eye Contact Restrictions'),
                    'face-slapping' => __tr('Face Slapping'),
                    'fantasy-gang-rape' => __tr('Fantasy Gang Rape'),
                    'fantasy-rape-play' => __tr('Fantasy Rape Play'),
                    'fellatio' => __tr('Fellatio'),
                    'finger-claws' => __tr('Finger Claws'),
                    'fire-play' => __tr('Fire Play'),
                    'fisting' => __tr('Fisting'),
                    'floggers' => __tr('Floggers'),
                    'flogging' => __tr('Flogging'),
                    'foot-worship' => __tr('Foot Worship'),
                    'foot-worship' => __tr('Foot Worship'),
                    'forced-bisexuality' => __tr('Forced Bisexuality'),
                    'forced-crossdressing' => __tr('Forced Crossdressing'),
                    'forced-feminization' => __tr('Forced Feminization'),
                    'forced-homosexuality' => __tr('Forced Homosexuality'),
                    'forced-milking' => __tr('Forced Milking'),
                    'forced-nudity' => __tr('Forced Nudity'),
                    'forced-servitude' => __tr('Forced Servitude'),
                    'furries' => __tr('Furries'),
                    'furry' => __tr('Furry'),
                    'gagging' => __tr('Gagging'),
                    'gags' => __tr('Gags'),
                    'gangbang' => __tr('Gangbang'),
                    'gates-of-hell' => __tr('Gates of Hell'),
                    'golden-showers' => __tr('Golden Showers'),
                    'gor-slave-training' => __tr('Gor Slave Training'),
                    'group-play' => __tr('Group Play'),
                    'hair-pulling' => __tr('Hair Pulling'),
                    'hairbrush-spanking' => __tr('Hairbrush Spanking'),
                    'harems' => __tr('Harems'),
                    'harnessing' => __tr('Harnessing'),
                    'high-heels' => __tr('High Heels'),
                    'hoods' => __tr('Hoods'),
                    'hot-wax' => __tr('Hot Wax'),
                    'hotwife' => __tr('Hotwife'),
                    'hucow' => __tr('Hucow'),
                    'human-kitten' => __tr('Human Kitten'),
                    'human-pet' => __tr('Human Pet'),
                    'human-puppy' => __tr('Human Puppy'),
                    'humiliation' => __tr('Humiliation'),
                    'hypnotism' => __tr('Hypnotism'),
                    'ice-cubes' => __tr('Ice Cubes'),
                    'impact-play' => __tr('Impact Play'),
                    'infantilism' => __tr('Infantilism'),
                    'inflatable-gag' => __tr('Inflatable Gag'),
                    'initiation-rites' => __tr('Initiation Rites'),
                    'injections' => __tr('Injections'),
                    'kidnapping' => __tr('Kidnapping'),
                    'kitten-play' => __tr('Kitten Play'),
                    'kneeling' => __tr('Kneeling'),
                    'knife-play' => __tr('Knife Play'),
                    'latex' => __tr('Latex'),
                    'leather-harness' => __tr('Leather Harness'),
                    'leather-restraints' => __tr('Leather Restraints'),
                    'lingerie' => __tr('Lingerie'),
                    'maid' => __tr('Maid'),
                    'manacles-irons' => __tr('Manacles & Irons'),
                    'mantra' => __tr('Mantra'),
                    'mascot' => __tr('Mascot'),
                    'masochist' => __tr('Masochist'),
                    'massage' => __tr('Massage'),
                    'master' => __tr('Master'),
                    'masturbation' => __tr('Masturbation'),
                    'medical-play' => __tr('Medical Play'),
                    'meditation' => __tr('Meditation'),
                    'milking' => __tr('Milking'),
                    'modeling' => __tr('Modeling'),
                    'mummification' => __tr('Mummification'),
                    'nipple-clamps' => __tr('Nipple Clamps'),
                    'nipple-piercing' => __tr('Nipple Piercing'),
                    'nipple-play' => __tr('Nipple Play'),
                    'otk' => __tr('OTK'),
                    'objectification' => __tr('Objectification'),
                    'orgasm-control' => __tr('Orgasm Control'),
                    'orgasm-denial' => __tr('Orgasm Denial'),
                    'orgy' => __tr('Orgy'),
                    'outdoor' => __tr('Outdoor'),
                    'over-the-knee' => __tr('Over the Knee'),
                    'owner' => __tr('Owner'),
                    'pain' => __tr('Pain'),
                    'pearl-necklace' => __tr('Pearl Necklace'),
                    'pearl-shower' => __tr('Pearl Shower'),
                    'pedicures' => __tr('Pedicures'),
                    'phallic-gag' => __tr('Phallic Gag'),
                    'phone-sex' => __tr('Phone Sex'),
                    'piercing' => __tr('Piercing'),
                    'pony-play' => __tr('Pony Play'),
                    'prison-scenes' => __tr('Prison Scenes'),
                    'property' => __tr('Property'),
                    'prostitution-fantasy' => __tr('Prostitution Fantasy'),
                    'punishment' => __tr('Punishment'),
                    'puppy-play' => __tr('Puppy Play'),
                    'pussy-whipping' => __tr('Pussy Whipping'),
                    'pussy-worship' => __tr('Pussy Worship'),
                    'riding-crops' => __tr('Riding Crops'),
                    'riding-the-horse' => __tr('Riding the Horse'),
                    'rimjobs' => __tr('Rimjobs'),
                    'rimming' => __tr('Rimming'),
                    'roleplaying' => __tr('Roleplaying'),
                    'rope-bondage' => __tr('Rope Bondage'),
                    'rope-harness' => __tr('Rope Harness'),
                    'rubber' => __tr('Rubber'),
                    'sadist' => __tr('Sadist'),
                    'scarification' => __tr('Scarification'),
                    'scat' => __tr('Scat'),
                    'scent' => __tr('Scent'),
                    'scratching' => __tr('Scratching'),
                    'sensory-deprivation' => __tr('Sensory Deprivation'),
                    'sensual-submissive' => __tr('Sensual Submissive'),
                    'shaving' => __tr('Shaving'),
                    'shibari' => __tr('Shibari'),
                    'shoe-fetish' => __tr('Shoe Fetish'),
                    'shoe-worship' => __tr('Shoe Worship'),
                    'single-tail' => __tr('Single Tail '),
                    'slapping' => __tr('Slapping'),
                    'slave' => __tr('Slave'),
                    'slave-hood' => __tr('Slave Hood'),
                    'sounding' => __tr('Sounding'),
                    'spandex' => __tr('Spandex'),
                    'spanking' => __tr('Spanking'),
                    'speculums' => __tr('Speculums'),
                    'speech-restrictions' => __tr('Speech Restrictions'),
                    'spit-roast' => __tr('Spit Roast'),
                    'spreader-bars' => __tr('Spreader Bars'),
                    'st-andrews-cross' => __tr('St Andrew\'s Cross'),
                    'stag' => __tr('Stag'),
                    'stocks' => __tr('Stocks'),
                    'straight-jackets' => __tr('Straight Jackets'),
                    'strap-ons' => __tr('Strap-ons'),
                    'strapping' => __tr('Strapping'),
                    'sub' => __tr('Sub'),
                    'submissive' => __tr('Submissive'),
                    'suction-cups' => __tr('Suction Cups'),
                    'suspension' => __tr('Suspension'),
                    'swapping' => __tr('Swapping'),
                    'swinging' => __tr('Swinging'),
                    'switch' => __tr('Switch'),
                    'tpe' => __tr('TPE '),
                    'tattooing' => __tr('Tattooing'),
                    'teasing' => __tr('Teasing'),
                    'tit-fucking' => __tr('Tit Fucking'),
                    'tongue-worship' => __tr('Tongue Worship'),
                    'total-power-exchange' => __tr('Total Power Exchange'),
                    'triple-penetration' => __tr('Triple Penetration'),
                    'underarms' => __tr('Underarms'),
                    'uniforms' => __tr('Uniforms'),
                    'verbal-humiliation' => __tr('Verbal Humiliation'),
                    'vibrators' => __tr('Vibrators'),
                    'violet-wand' => __tr('Violet Wand'),
                    'vixen' => __tr('Vixen'),
                    'voyeur' => __tr('Voyeur'),
                    'voyeurism' => __tr('Voyeurism'),
                    'wartenberg-wheel' => __tr('Wartenberg Wheel'),
                    'watersports' => __tr('Watersports'),
                    'whipping' => __tr('Whipping'),
                    'wooden-horse' => __tr('Wooden Horse'),
                    'wrestling' => __tr('Wrestling'),
                ];
$kinkOptions = $defaultKinkOptions;

if (isset($kinkList) && count($kinkList) > 0) {
    $kinkOptions = $kinkList;
}

$tattooOptions = [];
for ($i=0; $i <= 20; $i++) { 
    $tattooOptions[$i] = $i;
}

$childrenOptions = [];
for ($i=0; $i <= 5; $i++) { 
    $childrenOptions[$i] = $i;
}

return [
    'groups' => [
        'step-1' => [
            'title' => __tr('Step 1'),
            'icon'  => '<i class="far fa-smile text-primary"></i>',
            'items' => [
                'gender' => [
                    'name'          => __tr('I am a'),
                    'input_type'    => 'dynamic',
                ],
                'looking_for' => [
                    'name'          => __tr('Looking for'),
                    'input_type'    => 'select',
                    //'multiple'      => true,
                    'options' => [
                        'male'          => __tr('Male'),
                        'female'        => __tr('Female'),
                        'gender-fluid'  => __tr('Gender Fluid'),
                        'm2f'           => __tr('Trans Male to Female'),
                        'f2m'           => __tr('Trans Female to Male'),
                    ]
                ],
                'kinks' => [
                    'name'          => __tr('Your Interest/Kinks'),
                    'input_type'    => 'select',
                    //'multiple'      => true,
                    'options'       => $kinkOptions
                ],
                'dob' => [
                    'name'          => __tr('Date of Birth'),
                    'input_type'    => 'dynamic',
                ],
                'city' => [
                    'name'          => __tr('City/State'),
                    'input_type'    => 'dynamic',
                ],
                'ethnicity' => [
                    'name'          => __tr('Ethnicity'),
                    'input_type'    => 'select',
                    'frontend'      => false,
                    'options' => [
                        'white'             => __tr('White'),
                        'black'             => __tr('Black'),
                        'middle_eastern'    => __tr('Middle Eastern'),
                        'north_african'     => __tr('North African'),
                        'latin_american'    => __tr('Latin American'),
                        'mixed'             => __tr('Mixed'),
                        'asian'             => __tr('Asian'),
                        'other'             => __tr('Other'),
                    ]
                ],
            ]
        ],
        'step-2' => [
            'title' => __tr('Step 2'),
            'icon'  => '<i class="far fa-smile text-primary"></i>',
            'items' => [
                'body_type' => [
                    'name'          => __tr('Body Type'),
                    'input_type'    => 'select',
                    'options' => [
                        'slim'          => __tr('Slim'),
                        'sporty'        => __tr('Sporty'),
                        'curvy'         => __tr('Curvy'),
                        'round'         => __tr('Round'),
                        'supermodel'    => __tr('Supermodel'),
                        'average'       => __tr('Average'),
                        'other'         => __tr('Other')
                    ]
                ],
                'height' => [
                    'name' => __tr('Height (in cm)'),
                    'input_type'    => 'select',
                    'options' => [
                        "139"            => "139 cm",
                        "140"     => "140 cm (4' 7″)",
                        "141"            => "141 cm",
                        "142"     => "142 cm (4' 8″)",
                        "143"            => "143 cm",
                        "144"            => "144 cm",
                        "145"     => "145 cm (4' 9″)",
                        "146"            => "146 cm",
                        "147"    => "147 cm (4' 10″)",
                        "148"            => "148 cm",
                        "149"            => "149 cm",
                        "150"    => "150 cm (4' 11″)",
                        "151"            => "151 cm",
                        "152"     => "152 cm (5' 0″)",
                        "153"            => "153 cm",
                        "154"            => "154 cm",
                        "155"     => "155 cm (5' 1″)",
                        "156"            => "156 cm",
                        "157"     => "157 cm (5' 2″)",
                        "158"            => "158 cm",
                        "159"            => "159 cm",
                        "160"     => "160 cm (5' 3″)",
                        "161"            => "161 cm",
                        "162"            => "162 cm",
                        "163"     => "163 cm (5' 4″)",
                        "164"            => "164 cm",
                        "165"     => "165 cm (5' 5″)",
                        "166"            => "166 cm",
                        "167"            => "167 cm",
                        "168"     => "168 cm (5' 6″)",
                        "169"            => "169 cm",
                        "170"     => "170 cm (5' 7″)",
                        "171"            => "171 cm",
                        "172"            => "172 cm",
                        "173"     => "173 cm (5' 8″)",
                        "174"            => "174 cm",
                        "175"     => "175 cm (5' 9″)",
                        "176"            => "176 cm",
                        "177"            => "177 cm",
                        "178"    => "178 cm (5' 10″)",
                        "179"            => "179 cm",
                        "180"    => "180 cm (5' 11″)",
                        "181"            => "181 cm",
                        "182"            => "182 cm",
                        "183"     => "183 cm (6' 0″)",
                        "184"            => "184 cm",
                        "185"     => "185 cm (6' 1″)",
                        "186"            => "186 cm",
                        "187"            => "187 cm",
                        "188"     => "188 cm (6' 2″)",
                        "189"            => "189 cm",
                        "190"            => "190 cm",
                        "191"     => "191 cm (6' 3″)",
                        "192"            => "192 cm",
                        "193"     => "193 cm (6' 4″)",
                        "194"            => "194 cm",
                        "195"            => "195 cm",
                        "196"     => "196 cm (6' 5″)",
                        "197"            => "197 cm",
                        "198"     => "198 cm (6' 6″)",
                        "199"            => "199 cm",
                        "200"            => "200 cm",
                        "201"     => "201 cm (6' 7″)",
                        "202"            => "202 cm",
                        "203"     => "203 cm (6' 8″)",
                        "204"            => "204 cm",
                        "205"            => "205 cm",
                        "206"     => "206 cm (6' 9″)",
                        "207"            => "207 cm",
                        "208"    => "208 cm (6' 10″)",
                        "209"            => "209 cm",
                        "210"            => "210 cm",
                        "211"    => "211 cm (6' 11″)",
                        "212"            => "212 cm",
                        "213"     => "213 cm (7' 0″)",
                        "214"            => "214 cm",
                        "215"            => "215 cm",
                        "216"     => "216 cm (7' 1″)",
                        "217"            => "217 cm",
                        "218"            => "218 cm",
                        "220"     => "220 cm (7' 3″)",
                    ]
                ],
                'hair_color' => [
                    'name'          => __tr('Hair Color'),
                    'input_type'    => 'select',
                    'options'   => [
                        'brown'                     => __tr('Brown'),
                        'black'                     => __tr('Black'),
                        'white'                     => __tr('White'),
                        'sandy'                     => __tr('Sandy'),
                        'gray_or_partially_gray'    => __tr('Gray or Partially Gray'),
                        'red/auburn'                => __tr('Red/Auburn'),
                        'blond/strawberry'          => __tr('Blond/Strawberry'),
                        'blue'                      => __tr('Blue'),
                        'green'                     => __tr('Green'),
                        'orange'                    => __tr('Orange'),
                        'pink'                      => __tr('Pink'),
                        'purple'                    => __tr('Purple'),
                        'partly_or_completely_bald' => __tr('Partly or Completely Bald'),
                        'other'                     => __tr('Other')
                    ]
                ],
                'eye_color' => [
                    'name'          => __tr('Eye Color'),
                    'input_type'    => 'select',
                    'options'   => [
                        'brown'                     => __tr('Brown'),
                        'black'                     => __tr('Black'),
                        'white'                     => __tr('White'),
                        'sandy'                     => __tr('Sandy'),
                        'gray_or_partially_gray'    => __tr('Gray or Partially Gray'),
                        'red/auburn'                => __tr('Red/Auburn'),
                        'blond/strawberry'          => __tr('Blond/Strawberry'),
                        'blue'                      => __tr('Blue'),
                        'green'                     => __tr('Green'),
                        'orange'                    => __tr('Orange'),
                        'pink'                      => __tr('Pink'),
                        'purple'                    => __tr('Purple'),
                        'partly_or_completely_bald' => __tr('Partly or Completely Bald'),
                        'other'                     => __tr('Other')
                    ]
                ]
            ]
        ],
        /*'step-3' => [
            'title' => __tr('Step 3'),
            'icon'  => '<i class="far fa-smile text-primary"></i>',
            'items' => [
                'body_piercing' => [
                    'name'          => __tr('Do you have body piercing?'),
                    'input_type'    => 'select',
                    'options' => [
                        'yes'       => __tr('Yes'),
                        'no'        => __tr('No')
                    ]
                ],
                'no_of_piercing' => [
                    'name'          => __tr('How many piercing?'),
                    'input_type'    => 'select',
                    'options' => $tattooOptions
                ],
                'tattoo' => [
                    'name'          => __tr('Do you have a tattoo?'),
                    'input_type'    => 'select',
                    'options' => [
                        'yes'       => __tr('Yes'),
                        'no'        => __tr('No')
                    ]
                ],
                'no_of_tattoo' => [
                    'name'          => __tr('How many tattoo?'),
                    'input_type'    => 'select',
                    'options' => $tattooOptions
                ],
            ]
        ],*/
        'step-3' => [
            'title' => __tr('Step 3'),
            'icon'  => '<i class="far fa-smile text-primary"></i>',
            'items' => [
                'smoke' => [
                    'name'          => __tr('Do you smoke?'),
                    'input_type'    => 'select',
                    'options' => [
                        'never'             => __tr('Never'),
                        'occasionally'      => __tr('Occasionally'),
                        'daily'             => __tr('Daily'),
                        //'never'             => __tr('Never'),
                        //'i_some_sometimes'  => __tr('I Smoke Sometimes'),
                        //'chain_smoker'      => __tr('Chain Smoker')
                    ]
                ],
                'drink' => [
                    'name'          => __tr('Do you drink?'),
                    'input_type'    => 'select',
                    'options' => [
                        'never'             => __tr('Never'),
                        'i_drink_sometimes' => __tr('I Drink Sometimes')
                    ]
                ],
            ]
        ],
        'step-4' => [
            'title' => __tr('Step 4'),
            'icon'  => '<i class="far fa-smile text-primary"></i>',
            'items' => [
                'married' => [
                    'name'          => __tr('Are you married?'),
                    'input_type'    => 'select',
                    'options' => [
                        'yes'       => __tr('Yes'),
                        'no'        => __tr('No')
                    ]
                ],
                'children' => [
                    'name'          => __tr('Do you have children?'),
                    'input_type'    => 'select',
                    'options' => [
                        'yes'       => __tr('Yes'),
                        'no'        => __tr('No')
                    ]
                ],
                'no_of_children' => [
                    'name'          => __tr('No. of children?'),
                    'input_type'    => 'select',
                    'options' => $childrenOptions
                ],
                'relocate' => [
                    'name'          => __tr('Are you willing to relocate?'),
                    'input_type'    => 'select',
                    'options' => [
                        'yes'       => __tr('Yes'),
                        'no'        => __tr('No')
                    ]
                ],
            ]
        ],
        /*'personality' => [
            'title' => __tr('Personality'),
            'icon'  => '<i class="fas fa-child text-success"></i>',
            'items' => [
                'nature' => [
                    'name'          => __tr('Nature'),
                    'input_type'    => 'select',
                    'options' => [
                        'accommodating'     => __tr('Accommodating'),
                        'adventurous'       => __tr('Adventurous'),
                        'calm'              => __tr('Calm'),
                        'careless'          => __tr('Careless'),
                        'cheerful'          => __tr('Cheerful'),
                        'demanding'         => __tr('Demanding'),
                        'extroverted'       => __tr('Extroverted'),
                        'honest'            => __tr('Honest'),
                        'generous'          => __tr('Generous'),
                        'humorous'          => __tr('Humorous'),
                        'introverted'       => __tr('Introverted'),
                        'liberal'           => __tr('Liberal'),
                        'lively'            => __tr('Lively'),
                        'loner'             => __tr('Loner'),
                        'nervous'           => __tr('Nervous'),
                        'possessive'        => __tr('Possessive'),
                        'quiet'             => __tr('Quiet'),
                        'reserved'          => __tr('Reserved'),
                        'sensitive'         => __tr('Sensitive'),
                        'shy'               => __tr('Shy'),
                        'social'            => __tr('Social'),
                        'spontaneous'       => __tr('Spontaneous'),
                        'stubborn'          => __tr('Stubborn'),
                        'suspicious'        => __tr('Suspicious'),
                        'thoughtful'        => __tr('Thoughtful'),
                        'proud'             => __tr('Proud'),
                        'considerate'       => __tr('Considerate'),
                        'friendly'          => __tr('Friendly'),
                        'polite'            => __tr('Polite'),
                        'reliable'          => __tr('Reliable'),
                        'careful'           => __tr('Careful'),
                        'helpful'           => __tr('Helpful'),
                        'patient'           => __tr('Patient'),
                        'optimistic'        => __tr('Optimistic')
                    ]
                ],
                'friends' => [
                    'name'          => __tr('Friends'),
                    'input_type'    => 'select',
                    'options' => [
                        'no_friends'        => __tr('No friends'),
                        'some_friends'      => __tr('Some friends'),
                        'many_friends'      => __tr('Many friends'),
                        'only_good_friends' => __tr('Only good friends'),
                    ]
                ],
                'children' => [
                    'name'          => __tr('Children'),
                    'input_type'    => 'select',
                    'options' => [
                        "no_never"                          => __tr("No, never"),
                        "someday_maybe"                     => __tr("Someday, maybe"),
                        "expecting"                         => __tr("Expecting"),
                        "i_already_have_kids"               => __tr("already have kids"),
                        "i_have_kids_and_don't_want_more"   => __tr("have kids and don’t want more")
                    ]
                ],
                'pets' => [
                    'name'          => __tr('Pets'),
                    'input_type'    => 'select',
                    'options' => [
                        'none'      => __tr('None'),
                        'have_pets' => __tr('Have pets')
                    ]
                ]
            ]
        ],
        'lifestyle' => [
            'title' => __tr('Lifestyle'),
            'icon'  => '<i class="fas fa-umbrella-beach text-warning"></i>',
            'items' => [
                'religion' => [
                    'name'          => __tr('Religion'),
                    'input_type'    => 'select',
                    'options' => [
                        'muslim'        => __tr('Muslim'),
                        'atheist'       => __tr('Atheist'),
                        'buddhist'      => __tr('Buddhist'),
                        'catholic'      => __tr('Catholic'),
                        'christian'     => __tr('Christian'),
                        'hindu'         => __tr('Hindu'),
                        'jewish'        => __tr('Jewish'),
                        'agnostic'      => __tr('Agnostic'),
                        'sikh'          => __tr('Sikh'),
                        'other'         => __tr('Other')
                    ]
                ],
                'i_live_with' => [
                    'name'          => __tr('I live with'),
                    'input_type'    => 'select',
                    'options' => [
                        'alone'     => __tr('Alone'),
                        'parents'   => __tr('Parents'),
                        'friends'   => __tr('Friends'),
                        'partner'   => __tr('Partner'),
                        'children'  => __tr('Children'),
                        'other'     => __tr('Other')
                    ]
                ],
                'car' => [
                    'name'          => __tr('Car'),
                    'input_type'    => 'select',
                    'options' => [
                        'none' => __tr('None'),
                        'my_own_car' => __tr('My Own Car')
                    ]
                ],
                'travel' => [
                    'name'          => __tr('Travel'),
                    'input_type'    => 'select',
                    'options' => [
                        "yes_all_the_time"  => __tr("Yes, all the time"),
                        "yes_sometimes"     => __tr("Yes, sometimes"),
                        "not_very_much"     => __tr("Not very much"),
                        "no"                => __tr("No")
                    ]
                ],
            ]
        ],
        'favorites' => [
            'title' => __tr('Favorites'),
            'icon'  => '<i class="far fa-heart text-danger"></i>',
            'items' => [
                'music_genre' => [
                    'name'          => __tr('Music Genre'),
                    'input_type'    => 'textbox'
                ],
                'singer' => [
                    'name'          => __tr('Singer'),
                    'input_type'    => 'textbox'
                ],
                'song' => [
                    'name'          => __tr('Song'),
                    'input_type'    => 'textbox'
                ],
                'hobby' => [
                    'name'          => __tr('Hobby'),
                    'input_type'    => 'textbox'
                ],
                'sport' => [
                    'name'          => __tr('Sport'),
                    'input_type'    => 'textbox'
                ],
                'book' => [
                    'name'          => __tr('Book'),
                    'input_type'    => 'textbox'
                ],
                'dish' => [
                    'name'          => __tr('Dish'),
                    'input_type'    => 'textbox'
                ],
                'color' => [
                    'name'          => __tr('Color'),
                    'input_type'    => 'textbox'
                ],
                'movie' => [
                    'name'          => __tr('Movie'),
                    'input_type'    => 'textbox'
                ],
                'show' => [
                    'name'          => __tr('Show'),
                    'input_type'    => 'textbox'
                ],
                'inspired_from' => [
                    'name'          => __tr('Inspired From'),
                    'input_type'    => 'textbox'
                ]
            ]
        ],*/
    ]
];
