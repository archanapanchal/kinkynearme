<?php
/**
* UserSettingEngineInterface.php - Interface file
*
* This file is part of the UserSetting component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\UserSetting\Interfaces;

interface UserSettingEngineInterface
{
}
