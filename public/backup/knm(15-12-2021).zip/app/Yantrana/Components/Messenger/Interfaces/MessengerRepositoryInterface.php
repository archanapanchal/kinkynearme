<?php
/**
* MessengerRepositoryInterface.php - Interface file
*
* This file is part of the Messenger component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Messenger\Interfaces;

interface MessengerRepositoryInterface
{
}
