<?php
/**
* ManageForumCategoriesEngineBlueprint.php - Interface file
*
* This file is part of the ForumCategories component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\ForumCategories\Blueprints;

interface ManageForumCategoriesEngineBlueprint
{
}
