<?php
/**
* FilterEngineInterface.php - Interface file
*
* This file is part of the Filter component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Filter\Interfaces;

interface FilterEngineInterface
{
}
