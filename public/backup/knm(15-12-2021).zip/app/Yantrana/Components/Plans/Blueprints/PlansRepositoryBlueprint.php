<?php
/**
* PlansRepositoryBlueprint.php - Interface file
*
* This file is part of the Plans component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Plans\Blueprints;

interface PlansRepositoryBlueprint
{
}
