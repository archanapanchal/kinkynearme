<?php
/**
* CreditPackageRepositoryInterface.php - Interface file
*
* This file is part of the CreditPackage component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\CreditPackage\Interfaces;

interface CreditPackageRepositoryInterface
{
}
