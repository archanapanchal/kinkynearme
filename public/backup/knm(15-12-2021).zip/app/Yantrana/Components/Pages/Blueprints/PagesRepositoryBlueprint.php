<?php
/**
* PagesRepositoryBlueprint.php - Interface file
*
* This file is part of the Pages component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Pages\Blueprints;

interface PagesRepositoryBlueprint
{
}
