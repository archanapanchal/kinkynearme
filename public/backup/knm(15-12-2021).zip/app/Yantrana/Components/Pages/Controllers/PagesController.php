<?php
/**
* ManagePagesController.php - Controller file
*
* This file is part of the Pages component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Pages\Controllers;

use Illuminate\Http\Request;
use App\Yantrana\Support\CommonPostRequest;
use App\Yantrana\Base\BaseController;
use App\Yantrana\Components\Pages\ManagePagesEngine;
use App\Yantrana\Components\Pages\Requests\{ManagePagesAddRequest, ManagePagesEditRequest};
use Carbon\Carbon;

class PagesController extends BaseController
{
    /**
     * @var ManagePagesEngine - ManagePages Engine
     */
    protected $managePagesEngine;

    /**
     * Constructor.
     *
     * @param ManagePagesEngine $managePagesEngine - ManagePages Engine
     *-----------------------------------------------------------------------*/
    public function __construct(ManagePagesEngine $managePagesEngine)
    {
        $this->managePagesEngine = $managePagesEngine;
    }

    /**
     * Show Page View.
     *
     *-----------------------------------------------------------------------*/
    public function pageView($pageId=1)
    {   
        $processReaction = $this->managePagesEngine->prepareData($pageId);

        return $this->loadPageView('pages.view', $processReaction['data']);
    }
}
