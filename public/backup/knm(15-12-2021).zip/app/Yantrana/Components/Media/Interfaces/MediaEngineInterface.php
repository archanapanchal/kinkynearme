<?php
/**
* MediaEngineInterface.php - Interface file
*
* This file is part of the Media component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Media\Interfaces;

interface MediaEngineInterface
{
}
