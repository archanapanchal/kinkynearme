<?php

namespace App\Yantrana\Components\User\Models\Faker;

use App\Yantrana\Components\User\Models\UserProfile;

class FakerUserProfile extends UserProfile
{
    //timestamp false
    public $timestamps = false;
}
