<?php

namespace App\Yantrana\Components\User\Models\Faker;

use App\Yantrana\Components\User\Models\User;

class FakerUserModel extends User
{
    //timestamp false
    public $timestamps = false;
}
