<?php

namespace App\Yantrana\Components\User\Models\Faker;

use App\Yantrana\Components\User\Models\UserAuthorityModel;

class FakerUserAuthority extends UserAuthorityModel
{
    //timestamp false
    public $timestamps = false;
}
