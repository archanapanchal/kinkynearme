<?php
/**
* KinksRepositoryBlueprint.php - Interface file
*
* This file is part of the Kinks component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Kinks\Blueprints;

interface KinksRepositoryBlueprint
{
}
