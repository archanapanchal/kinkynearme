<?php
// WARNING!! DO NOT CHANGE HERE
return [
    'product_name' => 'loveria',
    'product_uid' => 'e7118867-1aad-45a4-af31-c7d90b984230',
    'your_email' => '',
    'registration_id' => '',
    'name' => 'Loveria',
    "version" => "2.0.0",
    'app_update_url' => env('APP_UPDATE_URL', 'https://product-central.livelyworks.net')
];